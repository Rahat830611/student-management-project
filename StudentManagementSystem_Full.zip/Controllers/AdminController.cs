
using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc; using StudentManagementSystem_Full.Data;
namespace StudentManagementSystem_Full.Controllers {
    [Authorize(Roles="Admin")] public class AdminController : Controller { private readonly AppDbContext _db; public AdminController(AppDbContext db){ _db=db; } public IActionResult Index(){ ViewBag.TotalStudents=_db.Students.Count(); ViewBag.TotalTeachers=_db.Teachers.Count(); ViewBag.TotalCourses=_db.Courses.Count(); return View(); } }
}
