
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using StudentManagementSystem_Full.Data;
namespace StudentManagementSystem_Full.Controllers {
    public class AccountController : Controller {
        private readonly AppDbContext _db;
        public AccountController(AppDbContext db) { _db = db; }
        public IActionResult Login() { return View(); }
        [HttpPost]
        public async Task<IActionResult> Login(string email, string password, string role) {
            var user = _db.Users.FirstOrDefault(u => u.Email==email && u.Password==password && u.Role==role);
            if(user==null) { ViewBag.Error="Invalid credentials"; return View(); }
            var claims = new List<Claim>{ new Claim(ClaimTypes.Name,user.Name), new Claim(ClaimTypes.Email,user.Email), new Claim(ClaimTypes.Role,user.Role) };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
            if(user.Role=="Admin") return RedirectToAction("Index","Admin"); if(user.Role=="Teacher") return RedirectToAction("Index","Teacher"); return RedirectToAction("Index","Student");
        }
        public async Task<IActionResult> Logout(){ await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme); return RedirectToAction("Login"); }
    }
}
