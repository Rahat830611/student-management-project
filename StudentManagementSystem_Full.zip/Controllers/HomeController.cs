
using Microsoft.AspNetCore.Mvc;
namespace StudentManagementSystem_Full.Controllers { public class HomeController : Controller { public IActionResult Index() { return View(); } } }
