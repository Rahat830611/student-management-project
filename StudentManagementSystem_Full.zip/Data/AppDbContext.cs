
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem_Full.Models;

namespace StudentManagementSystem_Full.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options) { }
        public DbSet<Student> Students { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentID = 1, DepartmentName = "CSE" },
                new Department { DepartmentID = 2, DepartmentName = "EEE" }
            );

            modelBuilder.Entity<Teacher>().HasData(
                new Teacher { TeacherID = 1, Name = "Dr. Ahsan", Designation = "Professor", DepartmentID = 1 }
            );

            modelBuilder.Entity<Course>().HasData(
                new Course { CourseID = 1, CourseName = "Intro to Programming", Credit = 3, TeacherID = 1, DepartmentID = 1 }
            );

            modelBuilder.Entity<User>().HasData(
                new User { UserID = 1, Email = "admin@example.com", Password = "Admin@123", Role = "Admin", Name = "Admin" },
                new User { UserID = 2, Email = "teacher@example.com", Password = "Teacher@123", Role = "Teacher", Name = "Teacher" },
                new User { UserID = 3, Email = "student@example.com", Password = "Student@123", Role = "Student", Name = "Student" }
            );

            modelBuilder.Entity<Student>().HasData(
                new Student { StudentID = 1, Name = "Rahat", Roll = "CSE-2001", Semester = 5, DepartmentID = 1 }
            );
        }
    }
}
