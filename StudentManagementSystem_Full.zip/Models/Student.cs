
namespace StudentManagementSystem_Full.Models
{
    public class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
        public string Roll { get; set; }
        public int Semester { get; set; }
        public int DepartmentID { get; set; }
        public Department? Department { get; set; }
    }
}
