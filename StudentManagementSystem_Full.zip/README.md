
Student Management System (Full) - ASP.NET Core MVC

How to run:
1. Install .NET 7 SDK.
2. cd into project folder.
3. dotnet restore
4. dotnet run

Default accounts:
- admin@example.com / Admin@123
- teacher@example.com / Teacher@123
- student@example.com / Student@123
